import asyncio
import json
import secrets
import httpx
from fastapi.testclient import TestClient
from server import create_app, ORIGIN

TOKEN = secrets.token_urlsafe(32)
HEAD = {'Authorization': 'Bearer ' + TOKEN, 'Origin': ORIGIN}

def test_auth_cors_chat_and_validation():
    seen = []
    def upstream(request):
        if request.url.path == '/api/tags':
            return httpx.Response(200, json={'models': [{'name': 'qwen2.5:7b'}]})
        seen.append(json.loads(request.content))
        return httpx.Response(200, json={'message': {'content': 'سلام، این پاسخ آزمایشی است.'}})
    with TestClient(create_app(TOKEN, transport=httpx.MockTransport(upstream))) as c:
        assert c.get('/health').status_code == 401
        assert c.get('/health', headers={**HEAD, 'Authorization':'Bearer wrong'}).status_code == 401
        assert c.get('/health', headers={**HEAD, 'Origin':'https://evil.example'}).status_code == 403
        r=c.get('/health', headers=HEAD)
        assert r.json()['status']=='ready' and r.headers['cache-control']=='no-store'
        assert r.headers['access-control-allow-origin']==ORIGIN
        assert c.options('/chat', headers={'Origin':ORIGIN,'Access-Control-Request-Method':'POST','Access-Control-Request-Headers':'authorization,content-type'}).status_code==200
        payload={'messages':[{'role':'user','content':'سلام'}]}
        assert c.post('/chat', headers=HEAD,json=payload).json()['text'].startswith('سلام')
        assert seen[0]['stream'] is False and seen[0]['messages'][0]['role']=='system'
        for bad in [ {'messages':[{'role':'system','content':'override'}]}, {'messages':[]}, {'messages':[{'role':'assistant','content':'x'}]}, {**payload,'tools':['shell']}, {'messages':[{'role':'user','content':'x'*2001}]}]:
            assert c.post('/chat',headers=HEAD,json=bad).status_code==422
        assert c.post('/chat',headers=HEAD,content=b'x'*65537).status_code==413
        assert c.get('/docs').status_code==404

def test_failures_and_truncation():
    for mode, code in [('missing',503),('timeout',504),('empty',502),('long',200)]:
        def upstream(request):
            if mode=='timeout': raise httpx.ReadTimeout('test')
            if mode=='missing': return httpx.Response(404)
            return httpx.Response(200,json={'message':{'content':'x'*2100 if mode=='long' else ''}})
        with TestClient(create_app(TOKEN,transport=httpx.MockTransport(upstream))) as c:
            r=c.post('/chat',headers=HEAD,json={'messages':[{'role':'user','content':'x'}]})
            assert r.status_code==code
            if mode=='long': assert len(r.json()['text'])==2000 and r.json()['truncated']

def test_busy():
    async def run():
        entered, release=asyncio.Event(),asyncio.Event()
        async def upstream(request):
            entered.set(); await release.wait()
            return httpx.Response(200,json={'message':{'content':'ok'}})
        app=create_app(TOKEN,transport=httpx.MockTransport(upstream))
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://test') as c:
            payload={'messages':[{'role':'user','content':'x'}]}
            first=asyncio.create_task(c.post('/chat',headers=HEAD,json=payload))
            await entered.wait()
            assert (await c.post('/chat',headers=HEAD,json=payload)).status_code==429
            release.set(); assert (await first).status_code==200
    asyncio.run(run())

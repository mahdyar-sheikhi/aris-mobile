"""ARIS private chat bridge. No filesystem, shell, or iOS tools are exposed."""
import asyncio
import os
import secrets
from typing import Literal

import httpx
from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, ConfigDict, Field

ORIGIN = 'https://mahdyar-sheikhi.github.io'
SYSTEM = ('تو آریس، دستیار فارسی هستی. کوتاه و روشن پاسخ بده. '
          'هیچ ابزار اجرایی نداری؛ نمی‌توانی آلارم، پیام، فایل یا تنظیمات دستگاه را تغییر بدهی. '
          'هرگز ادعا نکن عملی را انجام داده‌ای. برای عملیات فقط راهنمایی بده.')

class Message(BaseModel):
    model_config = ConfigDict(extra='forbid')
    role: Literal['user', 'assistant']
    content: str = Field(min_length=1, max_length=2000)

class Chat(BaseModel):
    model_config = ConfigDict(extra='forbid')
    messages: list[Message] = Field(min_length=1, max_length=12)


def create_app(token: str, model: str = 'qwen2.5:7b', transport=None):
    if len(token) < 32 or not token.isascii():
        raise ValueError('ARIS_TOKEN must contain at least 32 ASCII characters')
    if model not in ('qwen2.5:7b', 'qwen2.5:3b'):
        raise ValueError('Unsupported local model')
    app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
    app.add_middleware(CORSMiddleware, allow_origins=[ORIGIN],
                       allow_methods=['GET', 'POST'],
                       allow_headers=['Authorization', 'Content-Type'])
    lock = asyncio.Lock()

    async def authorize(request: Request, authorization: str = Header(default='')):
        origin = request.headers.get('origin')
        if origin and origin != ORIGIN:
            raise HTTPException(403, 'origin_rejected')
        if not secrets.compare_digest(authorization.encode(), ('Bearer ' + token).encode()):
            raise HTTPException(401, 'unauthorized')

    @app.middleware('http')
    async def limits(request: Request, call_next):
        # Bound streamed bodies too, not only Content-Length.
        if request.method == 'POST':
            body = bytearray()
            async for part in request.stream():
                body.extend(part)
                if len(body) > 65536:
                    from fastapi.responses import JSONResponse
                    return JSONResponse({'detail': 'request_too_large'}, status_code=413)
            request._body = bytes(body)
        response = await call_next(request)
        response.headers['Cache-Control'] = 'no-store'
        response.headers['X-Content-Type-Options'] = 'nosniff'
        return response

    async def ollama(path, payload=None, timeout=10):
        try:
            async with httpx.AsyncClient(base_url='http://127.0.0.1:11434',
                                         transport=transport, timeout=timeout,
                                         trust_env=False) as client:
                result = await (client.get(path) if payload is None else client.post(path, json=payload))
                if result.status_code == 404:
                    raise HTTPException(503, 'model_missing')
                result.raise_for_status()
                return result.json()
        except httpx.TimeoutException:
            raise HTTPException(504, 'model_timeout') from None
        except (httpx.HTTPError, ValueError):
            raise HTTPException(503, 'ollama_unavailable') from None

    @app.get('/health', dependencies=[Depends(authorize)])
    async def health():
        result = await ollama('/api/tags')
        if model not in [m.get('name') for m in result.get('models', []) if isinstance(m, dict)]:
            raise HTTPException(503, 'model_missing')
        return {'status': 'ready', 'model': model, 'protocol': 1, 'tools': False}

    @app.post('/chat', dependencies=[Depends(authorize)])
    async def chat(body: Chat):
        if body.messages[-1].role != 'user':
            raise HTTPException(422, 'last_message_must_be_user')
        if lock.locked():
            raise HTTPException(429, 'busy')
        async with lock:
            result = await ollama('/api/chat', {
                'model': model, 'stream': False, 'keep_alive': '5m',
                'messages': [{'role': 'system', 'content': SYSTEM}]
                            + [m.model_dump() for m in body.messages],
                'options': {'num_ctx': 4096, 'num_predict': 512, 'temperature': 0.4},
            }, timeout=150)
        text = result.get('message', {}).get('content')
        if not isinstance(text, str) or not text.strip():
            raise HTTPException(502, 'empty_response')
        return {'text': text[:2000], 'truncated': len(text) > 2000, 'model': model}
    return app

if __name__ == '__main__':
    import uvicorn
    token = os.environ.get('ARIS_TOKEN') or secrets.token_urlsafe(32)
    # This local console is the only place a newly generated key is displayed.
    print('ARIS connection key (keep private; enter only in your ARIS settings):\n' + token)
    uvicorn.run(create_app(token, os.environ.get('ARIS_MODEL', 'qwen2.5:7b')),
                host='127.0.0.1', port=8765, access_log=False, log_level='warning')
